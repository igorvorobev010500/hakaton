const btnUp = document.getElementById('scrollUp');
const btnDown = document.getElementById('scrollDown');

  btnUp.onclick = () => {
    window.scrollTo({
      top: 0, 
      behavior: 'smooth'
    });
  };

  btnDown.onclick = () => {
    window.scrollTo({
      top: document.body.scrollHeight, 
      behavior: 'smooth' 
    });
  };