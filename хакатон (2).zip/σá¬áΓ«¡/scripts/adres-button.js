const button = document.getElementById('adres-button');


  button.addEventListener('click', function() {
    window.location.href = '/pages/Sign-up.html';
  });