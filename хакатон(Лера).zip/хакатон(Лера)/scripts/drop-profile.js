const profileButton = document.querySelector('.profile-button');
const dropdownContent = document.querySelector('.dropdown-content');

function toggleDropdown() {
    if (dropdownContent.style.display === 'block') {
        dropdownContent.style.display = 'none';
    } else {
        dropdownContent.style.display = 'block';
    }
}

profileButton.addEventListener('click', function(event) {
    event.stopPropagation(); 
    toggleDropdown();
});

window.addEventListener('click', function(event) {
    if (!event.target.matches('.profile-button')) {
        dropdownContent.style.display = 'none';
    }
});